# usedf

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Vutify
```
vue add vuetify
```

### socket.io
```
npm install socket.io --save
```
### axios
```
npm install axios --save
```

### form-data
```
npm install form-data --save

 npm install --save dayjs
```


### vue-infinite-loading
```
npm install vue-infinite-loading --save


npm install vue-chartjs chart.js --save

```



### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
